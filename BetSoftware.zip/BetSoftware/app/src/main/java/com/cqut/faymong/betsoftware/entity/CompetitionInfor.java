package com.cqut.faymong.betsoftware.entity;

/**
 * Created by fei on 2018/11/14.
 */

public class CompetitionInfor {
    public String message;

    public CompetitionInfor(){}

    public CompetitionInfor(String msg){
        message = msg;
    }

}

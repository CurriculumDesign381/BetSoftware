package com.cqut.faymong.betsoftware.ui.first;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.cqut.faymong.betsoftware.R;

public class FirstActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.qq_tab_first);
    }

}
